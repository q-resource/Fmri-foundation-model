# 创建数据
x <- c(10, 30, 50, 70, 90, 100)
y1 <- c(0.32, 0.49, 0.52, 0.59, 0.61, 0.74) # individual
y2 <- c(0.27, 0.33, 0.45) # neurosynth
y3 <- c(0.14, 0.17, 0.21, 0.33, 0.33,0.74) # group mean

# 设置x轴的值
x2 <- c(10, 30, 50)
x3 <- c(10, 30, 50, 70, 90,100)

# 绘制图形
plot(x, y1, type = "o", col = "blue", ylim = c(0, 0.8), 
     xlab = "Percentage", ylab = "mean similarity", 
     main = "EFT Inference similarity using different mask", pch = 19)

# 添加第二套数据
lines(x2, y2, type = "o", col = "red", pch = 19)

# 添加第三套数据
lines(x3, y3, type = "o", col = "green", pch = 19)

# 添加图例
legend("topleft", legend = c("Individual", "Neurosynth", "Group Mean"), 
       col = c("blue", "red", "green"), lty = 1, pch = 19)

# 在 x=50 位置添加竖线虚线
abline(v = 50, col = "black", lty = 2)  # lty = 2 表示虚线


# 创建数据
x <- c(10, 30, 50, 70, 90, 100)
y1 <- c(0.36, 0.5, 0.47, 0.51, 0.61, 0.72) # individual
y2 <- c(0.28, 0.37, 0.41) # neurosynth
y3 <- c(0.17, 0.21, 0.34, 0.44, 0.6,0.72) # group mean

# 设置x轴的值
x2 <- c(10, 30, 50)
x3 <- c(10, 30, 50, 70, 90,100)

# 绘制图形
plot(x, y1, type = "o", col = "blue", ylim = c(0, 0.8), 
     xlab = "Percentage", ylab = "mean similarity", 
     main = "SST Inference similarity using different mask", pch = 19)

# 添加第二套数据
lines(x2, y2, type = "o", col = "red", pch = 19)

# 添加第三套数据
lines(x3, y3, type = "o", col = "green", pch = 19)

# 添加图例
legend("topleft", legend = c("Individual", "Neurosynth", "Group Mean"), 
       col = c("blue", "red", "green"), lty = 1, pch = 19)
# 在 x=50 位置添加竖线虚线
abline(v = 50, col = "black", lty = 2)  # lty = 2 表示虚线




