# 安装并加载必要的包
if (!require("NbClust")) {
  install.packages("NbClust")
}
library(NbClust)

# 从CSV文件中读取矩阵
mat1 <- read.csv("Imat1.csv", header = T)
mat2 <- read.csv("Imat2.csv", header = T)
mat3 <- read.csv("Imat3.csv", header = T)
mat4 <- read.csv("Imat4.csv", header = T)
mat5 <- read.csv("Imat5.csv", header = T)
mat6 <- read.csv("Imat6.csv", header = T)

# 矩阵名称
matrix_names <- c("EFT BL predict neutral by angry", 
                  "EFT FU2 predict neutral by angry", 
                  "EFT FU3 predict neutral by angry", 
                  "SST BL predict stops by gos", 
                  "SST FU2 predict stops by gos", 
                  "SST FU3 predict stops by gos")

# 定义函数寻找最优聚类数并打印聚类数量
find_optimal_clusters_and_counts <- function(mat) {
  # 计算距离矩阵
  dist_mat <- dist(mat, method = "manhattan")
  
  # 使用 NbClust 寻找最优聚类数
  nb <- NbClust(data = as.data.frame(mat), diss = dist_mat, distance = NULL, 
                min.nc = 2, max.nc = 10, method = "complete", index = "all")
  
  optimal_clusters <- nb$Best.nc[1]
  
  # 进行层次聚类
  hc <- hclust(dist_mat, method = "complete")
  
  # 使用最优聚类数进行切割
  clusters <- cutree(hc, k = optimal_clusters)
  
  # 统计每个聚类的数量
  cluster_counts <- table(clusters)
  
  return(list(optimal_clusters = optimal_clusters, cluster_counts = cluster_counts, hc = hc))
}

# 对每个矩阵寻找最优聚类数并打印聚类数量
results <- lapply(list(mat1, mat2, mat3, mat4, mat5, mat6), find_optimal_clusters_and_counts)

# 绘制每个矩阵的聚类树状图
par(mfrow = c(2, 3), mar = c(5, 4, 4, 2)) # 设置布局和边距
for (i in 1:6) {
  plot(results[[i]]$hc, labels = FALSE, main = paste(matrix_names[i], "\nOptimal clusters:", results[[i]]$optimal_clusters), xlab = "", sub = "")
  rect.hclust(results[[i]]$hc, k = results[[i]]$optimal_clusters, border = "red")
  
  # 添加每个聚类的数量标注
  cluster_labels <- as.character(results[[i]]$cluster_counts)
  cluster_positions <- cutree(results[[i]]$hc, k = results[[i]]$optimal_clusters)
  cluster_centers <- tapply(1:length(results[[i]]$hc$order), cluster_positions[results[[i]]$hc$order], mean)
  
  for (j in 1:length(cluster_centers)) {
    text(cluster_centers[j], par("usr")[3] + (par("usr")[4] - par("usr")[3]) * 0.05, 
         labels = cluster_labels[j], col = "blue", cex = 0.8, pos = 3, xpd = TRUE)
  }
}









# 安装并加载必要的包
if (!require("NbClust")) {
  install.packages("NbClust")
}
library(NbClust)



# 从CSV文件中读取矩阵
mat1 <- read.csv("Smat1.csv", header = T)
mat2 <- read.csv("Smat2.csv", header = T)
mat3 <- read.csv("Smat1.csv", header = T)
mat4 <- read.csv("Smat2.csv", header = T)
mat5 <- read.csv("Smat1.csv", header = T)
mat6 <- read.csv("Smat2.csv", header = T)
mat7 <- read.csv("Smat1.csv", header = T)
mat8 <- read.csv("Smat2.csv", header = T)

# 矩阵名称
matrix_names <- c("MDD+HC cohort", 
                  "AUD+HC cohort", 
                  "MDD+HC cohort", 
                  "AUD+HC cohort", 
                  "MDD+HC cohort", 
                  "AUD+HC cohort",
                  "MDD+HC cohort", 
                  "AUD+HC cohort")

# 定义函数寻找最优聚类数并打印聚类数量
find_optimal_clusters_and_counts <- function(mat) {
  # 计算距离矩阵
  dist_mat <- dist(mat, method = "manhattan")
  
  # 使用 NbClust 寻找最优聚类数
  nb <- NbClust(data = as.data.frame(mat), diss = dist_mat, distance = NULL, 
                min.nc = 2, max.nc = 10, method = "complete", index = "all")
  
  optimal_clusters <- nb$Best.nc[1]
  
  # 进行层次聚类
  hc <- hclust(dist_mat, method = "complete")
  
  # 使用最优聚类数进行切割
  clusters <- cutree(hc, k = optimal_clusters)
  
  # 统计每个聚类的数量
  cluster_counts <- table(clusters)
  
  return(list(optimal_clusters = optimal_clusters, cluster_counts = cluster_counts, hc = hc))
}

# 对每个矩阵寻找最优聚类数并打印聚类数量
results <- lapply(list(mat1, mat2, mat3, mat4, mat5, mat6, mat7, mat8), find_optimal_clusters_and_counts)

# 绘制每个矩阵的聚类树状图
par(mfrow = c(3, 3), mar = c(5, 4, 4, 2)) # 设置布局和边距
for (i in 1:8) {
  plot(results[[i]]$hc, labels = FALSE, main = paste(matrix_names[i], "\nOptimal clusters:", results[[i]]$optimal_clusters), xlab = "", sub = "")
  rect.hclust(results[[i]]$hc, k = results[[i]]$optimal_clusters, border = "red")
}



