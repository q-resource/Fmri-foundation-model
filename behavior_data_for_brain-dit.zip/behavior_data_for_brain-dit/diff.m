clear all;
clc;
% Initialize results table
results = table([], [], [], 'VariableNames', {'t_value', 'p_value', 'cohens_d'});
% 读取六个包含特征的CSV文件
files = { 'FU3_SST_first_half.csv', 'FU3_SST_second_half.csv'};
% Read the six feature CSV files
data = cell(2,1);
for i = 1:2
data{i} = readtable(files{i});
end
% 读取第七个和第八个文件
file7 = readtable('fu3_group_70_125_part1.csv');
file8 = readtable('fu3_group_70_125_part2.csv');
% Process each feature file separately
for i = 1:2
% Match IDs from file7 and extract second column features
[~, idx7] = ismember(file7{:,1}, data{i}{:,1});
features7 = data{i}{idx7(idx7>0),2};
% Match IDs from file8 and extract second column features
[~, idx8] = ismember(file8{:,1}, data{i}{:,1});
features8 = data{i}{idx8(idx8>0),2};
% Perform t-test
[~, p, ~, stats] = ttest2(features7, features8, 'Vartype', 'unequal');
t_value = stats.tstat;
% Calculate Cohen's d
mean7 = mean(features7);
mean8 = mean(features8);
n7 = length(features7);
n8 = length(features8);
pooled_std = sqrt(((n7-1)*var(features7) + (n8-1)*var(features8))/(n7+n8-2));
cohens_d = (mean7 - mean8) / pooled_std;
% Store results for this file
results(i,:) = {t_value, p, cohens_d};
% Display results for this file
fprintf('Results for %s:\n', files{i});
fprintf('T-value: %.4f\n', t_value);
fprintf('P-value: %.4f\n', p);
fprintf('Cohen''s d: %.4f\n\n', cohens_d);
end
% Add file names to results table for clarity
results.FileName = files';
results = results(:, {'FileName', 't_value', 'p_value', 'cohens_d'});
% Save results to CSV
writetable(results, 'ttest_resultsfu3ssta.csv');
fprintf('Results saved to ttest_results.csv\n');