% 假设 imagenTable 是一个包含所有被试数据的表格，字段包括：
% subject（编号）, site, sex, age_group

% 示例字段替代
% site → Acquisition
% sex → Gender
% age_group → Race（分类含义相似，仅用于逻辑处理）

% 初始化
subjects = imagenTable.subject;
sites = imagenTable.site;
sexes = imagenTable.sex;
age_groups = imagenTable.age_group;

% 获取每个字段的唯一类别数量
unique_sites = unique(sites);
unique_sexes = unique(sexes);
unique_age_groups = unique(age_groups);

n_sites = length(unique_sites);
n_sexes = length(unique_sexes);
n_age_groups = length(unique_age_groups);

% 总细分类数量
total_classes = n_sites * n_sexes * n_age_groups;

% 将类别变量转为数值索引
site_idx = double(categorical(sites));
sex_idx = double(categorical(sexes));
age_idx = double(categorical(age_groups));

% 生成细分类标签（组合索引）
class_idx = 1 + ...
    (site_idx - 1) * n_sexes * n_age_groups + ...
    (sex_idx - 1) * n_age_groups + ...
    age_idx;

% 打乱顺序
n_subjects = length(subjects);
shuffled_idx = randperm(n_subjects);
class_idx = class_idx(shuffled_idx);
subjects = subjects(shuffled_idx);

% 初始化训练/测试标记
train_idx = false(n_subjects, 1);
test_idx = false(n_subjects, 1);

% stratified split
for i = 1:total_classes
   class_mask = class_idx == i;
   n_class = sum(class_mask);

   if n_class == 0
       continue; % 跳过空类
   end

   n_train = round(0.8 * n_class);
   n_test = n_class - n_train;

   train_idx(class_mask) = [true(n_train,1); false(n_test,1)];
   test_idx(class_mask) = ~train_idx(class_mask);
end

% 最终划分的 subject ID
train_subjects = subjects(train_idx);
test_subjects = subjects(test_idx);

% 可选保存
save('IMAGEN_train_test_split.mat', 'train_subjects', 'test_subjects', 'train_idx', 'test_idx');
